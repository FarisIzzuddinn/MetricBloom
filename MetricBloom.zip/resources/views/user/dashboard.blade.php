@extends('layout')
@section('title', 'Admin Dashboard')
@section('body')
    @include('sidebar')
        <div class="main">
            <div class="right-sidebar">
                <div>
                    <h3 class="fw-bold fs-4 my-3">User Dashboard</h3><br>
                </div>
            </div>
        </div>
@endsection
