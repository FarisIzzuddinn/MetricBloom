<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: inline;">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="dropdown-item">
        Logout
    </button>
</form><?php /**PATH C:\laragon\www\MetricBloom\resources\views/logout.blade.php ENDPATH**/ ?>