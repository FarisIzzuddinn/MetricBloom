<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="<?php echo e(asset("css/table.css")); ?>">

<style>
    .chart-container {
        position: relative;
        width: 100%;
        height: 100%;
    }

    canvas {
        width: 100% !important;
        height: 300px !important; /* Adjust height as needed */
        object-fit: contain; /* Maintain aspect ratio */
    }
</style>

<?php
    $chartConfiguration = App\Models\ChartConfiguration::first();
?>

<?php if($chartConfiguration): ?>
    <?php
        $chartTitle = $chartConfiguration->chart_title;
    ?>
<?php else: ?>
    <?php
        $chartTitle = 'Default Chart Title'; // Provide a fallback title or handle the absence of data appropriately
    ?>
<?php endif; ?>

<div class="row">
    <div class="col-lg-3 col-md-6 mt-1">
        <div class="card bg-primary text-white">
            <div class="card-header">Total KPIs</div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($totalKpis); ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mt-1">
        <div class="card bg-success text-white">
            <div class="card-header">Achieved</div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($achievedKpis); ?></h5>
            </div>
        </div>
    </div> 
    <div class="col-lg-3 col-md-6 mt-1">
        <div class="card bg-warning text-white">
            <div class="card-header">Pending</div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($pendingKpis); ?></h5>
            </div>
        </div>
    </div>
    <div class="col-lg-3 col-md-6 mt-1">
        <div class="card bg-info text-white">
            <div class="card-header">Average Achievement</div>
            <div class="card-body">
                <h5 class="card-title"><?php echo e($averageAchievement); ?>%</h5>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-8 col-md-12 mt-3">
        <div class="card">
            <div class="card-header">KPI Performance Over Time</div>
            <div class="card-body chart-container">
                <canvas id="performanceChart"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-4 col-md-12 mt-3">
        <div class="card">
            <div class="card-header">KPI Status Distribution</div>
            <div class="card-body chart-container">
                <canvas id="statusDistributionChart"></canvas>
            </div>
        </div>
    </div>
</div>



<div class="row mt-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">KPI OVERVIEW</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr class="table-secondary text-secondary small-text">
                                <th >BIL</th>
                                <th >TERAS</th>
                                <th >SO</th>
                                <th >NEGERI</th>
                                <th >PEMILIK</th>
                                <th >KPI</th>
                                <th >PERNYATAAN KPI</th>
                                <th >SASARAN</th>
                                <th >PENCAPAIAN</th>
                                <th >PERATUS PENCAPAIAN</th>
                                <th >STATUS</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $addKpis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $addkpi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td class="small-text text-secondary"><?php echo e($index + 1); ?></td>
                                    <td class="small-text"><?php echo e($addkpi->teras ? $addkpi->teras->id : 'No Teras Found'); ?></td>
                                    <td class="small-text kpi-statement"><?php echo e($addkpi->so ? $addkpi->so->id : 'No SO Found'); ?></td> 
                                    <td class="small-text"><?php echo e($addkpi->negeri); ?></td>
                                    <td class="small-text"><?php echo e($addkpi->user->name); ?></td>
                                    <td class="small-text"><?php echo e($addkpi->kpi); ?></td>
                                    <td class="small-text kpi-statement"><?php echo e($addkpi->pernyataan_kpi); ?></td>
                                    <td class="small-text"><?php echo e($addkpi->sasaran); ?></td>
                                    <td class="small-text"><?php echo e($addkpi->pencapaian); ?>%</td>
                                    <td class="small-text"><?php echo e(number_format($addkpi->peratus_pencapaian, 2)); ?>%</td>
                                    <td class="small-text">
                                        <?php if($addkpi->peratus_pencapaian >= 75): ?>
                                            <span class="badge text-bg-success">Tinggi</span>
                                        <?php elseif($addkpi->peratus_pencapaian >= 50): ?>
                                            <span class="badge text-bg-warning">Sederhana</span>
                                        <?php else: ?>
                                            <span class="badge text-bg-danger">Rendah</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            
                            
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const labels = <?php echo json_encode($labels, 15, 512) ?>;
    const data = <?php echo json_encode($data, 15, 512) ?>;
    const chartTitle = <?php echo json_encode($chartTitle, 15, 512) ?>;

    const backgroundColors = [
        'rgba(255, 99, 132, 0.2)',
        'rgba(54, 162, 235, 0.2)',
        'rgba(255, 206, 86, 0.2)',
        'rgba(75, 192, 192, 0.2)',
        'rgba(153, 102, 255, 0.2)',
        'rgba(255, 159, 64, 0.2)'
    ];

    const borderColors = [
        'rgba(255, 99, 132, 1)',
        'rgba(54, 162, 235, 1)',
        'rgba(255, 206, 86, 1)',
        'rgba(75, 192, 192, 1)',
        'rgba(153, 102, 255, 1)',
        'rgba(255, 159, 64, 1)'
    ];

    // Performance Chart
    const ctx1 = document.getElementById('performanceChart').getContext('2d');
    const chart1 = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: chartTitle || 'Default Title',
                data: data,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            }]
        },
        options: {
            indexAxis: 'y',
            maintainAspectRatio: false,
        }
    });

    // KPI Status Distribution Chart
    const ctx2 = document.getElementById('statusDistributionChart').getContext('2d');
    const chart2 = new Chart(ctx2, {
        type: 'doughnut', // Change to 'pie' or 'doughnut' if appropriate
        data: {
            labels: labels, // Ensure this is correct for pie chart
            datasets: [{
                label: chartTitle || 'Default Title',
                data: data.length > 0 ? data : [1], // Ensure there's data to render
                backgroundColor: data.length > 0 ? backgroundColors : ['#f0f0f0'], 
                borderColor: data.length > 0 ? borderColors : ['#ccc'], 
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                tooltip: {
                    callbacks: {
                        label: function(tooltipItem) {
                            return `${tooltipItem.label}: ${tooltipItem.raw}`;
                        }
                    }
                },
                title: { 
                    display: true,
                    text: chartTitle || 'Default Pie Chart Title', // Display the dynamic or default title
                    font: {
                        size: 18, // Size of the title
                    }
                }
            }
        }
    });

    if (data.length === 0 || data.every(item => item === 0)) {
        const ctx = ctx2;
        ctx.font = "16px Arial";
        ctx.textAlign = "center";
        ctx.fillStyle = "#666"; // Grey color for the text
        ctx.fillText("No Data Available", ctx.canvas.width / 2, ctx.canvas.height / 2);
    }
</script>
<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\MetricBloom\resources\views/admin/dashboard/index.blade.php ENDPATH**/ ?>