<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<style>
    h3{
        text-align: start;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-lg-12">
            <div class="container-fluid">
                <h3 class="fw-bold fs-4 ms-2 mb-3">Create SO
                    <a href="<?php echo e(url('so')); ?>" class="btn btn-danger float-end">back</a>
                </h3>
            </div>

            <div class="card-body">
                <form action="<?php echo e(url('so')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="mb-3">
                        <label for="SO" class="title">SO Name</label>
                        <input type="text" name="SO" class="form-control">
                    </div>
                    <div class="mb-3">
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layoutNoName', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\MetricBloom\resources\views/admin/SO/create.blade.php ENDPATH**/ ?>